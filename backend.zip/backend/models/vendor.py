# backend/models/vendor.py
from backend.extensions import db
from datetime import datetime

class Vendor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False)
    contact_name = db.Column(db.String(120))
    email = db.Column(db.String(180))
    phone = db.Column(db.String(50))
    categories = db.Column(db.String(255))  # "HVAC,Electrical"
    address = db.Column(db.String(255))
    notes = db.Column(db.Text, default="")
    rating = db.Column(db.Integer, default=0)
    status = db.Column(db.String(40), default="Active")
    logo_url = db.Column(db.String(255))     # <— NUEVO
    website = db.Column(db.String(255))      # <— NUEVO
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
