# backend/models/task_comment.py
from datetime import datetime
from backend.extensions import db


class TaskComment(db.Model):
    __tablename__ = "task_comment"

    id = db.Column(db.Integer, primary_key=True)

    # Tarea a la que pertenece el comentario
    task_id = db.Column(
        db.Integer,
        db.ForeignKey("task.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # Contenido del comentario
    body = db.Column(db.Text, nullable=False)

    # Metadatos opcionales del autor
    user_id = db.Column(db.Integer, nullable=True)
    author_name = db.Column(db.String(120), nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
