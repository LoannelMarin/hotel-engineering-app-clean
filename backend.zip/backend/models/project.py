# backend/models/project.py
# -*- coding: utf-8 -*-
from datetime import datetime
from backend.extensions import db

class Project(db.Model):
    __tablename__ = "project"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False, unique=True)
    color_legend = db.Column(db.JSON, default=dict)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow,
                           onupdate=datetime.utcnow, nullable=False)

    room_statuses = db.relationship(
        "ProjectRoomStatus", backref="project", lazy=True,
        cascade="all, delete-orphan", passive_deletes=True,
    )
    room_audits = db.relationship(
        "ProjectRoomAudit", backref="project", lazy=True,
        cascade="all, delete-orphan", passive_deletes=True,
        order_by="desc(ProjectRoomAudit.id)"
    )

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "color_legend": self.color_legend or {},
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

class ProjectRoomStatus(db.Model):
    __tablename__ = "project_room_status"

    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey("project.id", ondelete="CASCADE"), nullable=False)
    room_number = db.Column(db.String(10), nullable=False, index=True)

    status = db.Column(db.String(40), default="N/A")
    notes = db.Column(db.Text, default="")

    updated_by = db.Column(db.String(120))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow,
                           onupdate=datetime.utcnow, nullable=False)

    __table_args__ = (
        db.UniqueConstraint("project_id", "room_number", name="uq_project_room"),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "project_id": self.project_id,
            "room_number": self.room_number,
            "status": self.status,
            "notes": self.notes or "",
            "updated_by": self.updated_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

class ProjectRoomAudit(db.Model):
    __tablename__ = "project_room_audit"

    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey("project.id", ondelete="CASCADE"), nullable=False)
    room_number = db.Column(db.String(10), nullable=False, index=True)

    prev_status = db.Column(db.String(40))
    new_status  = db.Column(db.String(40))
    notes = db.Column(db.Text, default="")

    updated_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "project_id": self.project_id,
            "room_number": self.room_number,
            "prev_status": self.prev_status,
            "new_status": self.new_status,
            "notes": self.notes or "",
            "updated_by": self.updated_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
