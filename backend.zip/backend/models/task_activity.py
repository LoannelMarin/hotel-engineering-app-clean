# backend/models/task_activity.py
from datetime import datetime, timezone
from backend.extensions import db


class TaskActivity(db.Model):
    __tablename__ = "task_activity"

    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey("task.id"), index=True, nullable=False)

    # Qué pasó
    action = db.Column(db.String(40), nullable=False)  # create, update, move, delete
    changes = db.Column(db.Text, default="")  # JSON string: {"field":{"old":...,"new":...}}

    # Quién lo hizo (estilo InventoryLog)
    user_id = db.Column(db.Integer, nullable=True)
    user_email = db.Column(db.String(120), nullable=True)
    user_name = db.Column(db.String(120), nullable=True)

    # Compatibilidad hacia atrás (mostrar directamente):
    actor = db.Column(db.String(120), default="")  # display fallback

    created_at = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=True
    )
