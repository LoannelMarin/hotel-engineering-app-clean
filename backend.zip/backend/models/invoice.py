from backend.extensions import db
from datetime import datetime

class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice_number = db.Column(db.String(120), unique=True, nullable=False)
    vendor_id = db.Column(db.Integer, db.ForeignKey("vendor.id"), nullable=False)
    amount = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(10), default="USD")
    due_date = db.Column(db.DateTime)

    # Nuevos/extendidos
    order_date = db.Column(db.DateTime, nullable=True)
    post_date  = db.Column(db.DateTime, nullable=True)

    status = db.Column(db.String(40), default="Draft")
    linked_quote_id = db.Column(db.Integer, db.ForeignKey("quote.id"), nullable=True)
    po_number = db.Column(db.String(120))
    attachments = db.Column(db.Text, default="")
    notes = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ⬇️ NUEVO: aquí guardamos "30 Days Net" o "Due on receipt"
    payment_terms = db.Column(db.String(64), nullable=True)

    vendor = db.relationship("Vendor", backref="invoices", lazy=True)
