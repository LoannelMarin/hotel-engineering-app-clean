# backend/models/task.py
from datetime import datetime
from backend.extensions import db

class Task(db.Model):
    __tablename__ = "task"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    description = db.Column(db.Text, default="")
    status = db.Column(db.String(40), default="Not Started")  # Not Started, In Progress, Waiting for Approval, Complete
    priority = db.Column(db.String(20), default="Medium")     # Low/Medium/High
    assignee = db.Column(db.String(120))
    workstream = db.Column(db.String(80))                     # e.g., "Fire Inspection"
    image_url = db.Column(db.Text)                            # optional photo
    room = db.Column(db.String(10))
    floor = db.Column(db.String(10))
    due_date = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
