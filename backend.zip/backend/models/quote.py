from backend.extensions import db
from datetime import datetime

class Quote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quote_number = db.Column(db.String(120), unique=True, nullable=False)
    vendor_id = db.Column(db.Integer, db.ForeignKey("vendor.id"), nullable=False)
    scope_title = db.Column(db.String(180))
    scope_detail = db.Column(db.Text, default="")
    requested_at = db.Column(db.DateTime)
    received_at = db.Column(db.DateTime)
    amount = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(10), default="USD")
    status = db.Column(db.String(40), default="Requested")
    linked_task_id = db.Column(db.Integer, db.ForeignKey("task.id"), nullable=True)
    linked_project_id = db.Column(db.Integer, db.ForeignKey("project.id"), nullable=True)
    attachments = db.Column(db.Text, default="")  # simple CSV of URLs
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    vendor = db.relationship("Vendor", backref="quotes", lazy=True)
