# -*- coding: utf-8 -*-
"""
Script DEV para asegurar el esquema en SQLite:
- Importa modelos (para poblar metadata)
- Crea tablas que falten con create_all()
- Agrega columnas faltantes con ALTER TABLE (sin NOT NULL ni DEFAULT)
- Backfill de timestamps en tabla inspection
- Crea índices útiles si faltan

Uso:
    python backend/tools/ensure_sqlite_schema.py
"""

import os
import sys
from contextlib import suppress

from sqlalchemy import inspect, text

# ------- Resolver imports del proyecto -------
THIS_DIR = os.path.dirname(__file__)
BACKEND_DIR = os.path.abspath(os.path.join(THIS_DIR, ".."))
PROJECT_ROOT = os.path.abspath(os.path.join(BACKEND_DIR, ".."))
for p in (PROJECT_ROOT, BACKEND_DIR):
    if p not in sys.path:
        sys.path.insert(0, p)

try:
    from backend.app import create_app  # type: ignore
    from backend.config import Config    # type: ignore
    from backend.extensions import db    # type: ignore
except Exception:
    # Fallback si se ejecuta desde /backend
    from app import create_app           # type: ignore
    from config import Config            # type: ignore
    from extensions import db            # type: ignore


def _import_models():
    """
    Importa módulos de modelos para que SQLAlchemy conozca todas las tablas
    antes de llamar a create_all().
    Agrega aquí otros modelos conforme crezcan.
    """
    with suppress(Exception):
        import backend.models.inspection  # noqa: F401
    # con el patrón anterior puedes seguir añadiendo más:
    # with suppress(Exception):
    #     import backend.models.asset  # noqa: F401


def _create_indexes_if_missing(conn, insp):
    """
    Crea índices útiles si la tabla 'inspection' existe y los índices no están.
    """
    if not insp.has_table("inspection"):
        return

    existing_indexes = {ix["name"] for ix in insp.get_indexes("inspection")}
    wanted = {
        "ix_inspection_status": "CREATE INDEX ix_inspection_status ON inspection(status)",
        "ix_inspection_created_at": "CREATE INDEX ix_inspection_created_at ON inspection(created_at)",
        "ix_inspection_inspection_date": "CREATE INDEX ix_inspection_inspection_date ON inspection(inspection_date)",
    }
    for name, ddl in wanted.items():
        if name not in existing_indexes:
            try:
                conn.exec_driver_sql(ddl)
                print(f"[ensure] índice creado: {name}")
            except Exception as e:
                print(f"[ensure] ! error creando índice {name}: {e}")


def ensure_schema():
    app = create_app(Config)

    with app.app_context():
        engine = db.engine
        uri = app.config.get("SQLALCHEMY_DATABASE_URI", "")
        print(f"[ensure] DB URI: {uri}")

        # 0) Importa modelos para poblar metadata
        _import_models()

        # 1) Crear tablas que no existan
        print("[ensure] Creando tablas que no existan…")
        db.create_all()
        print("[ensure] create_all() OK")

        # 2) Sólo parche de columnas en SQLite
        if not uri.startswith("sqlite"):
            print("[ensure] Parche de columnas pensado para SQLite. Saliendo.")
            return

        insp = inspect(engine)
        tables = list(db.metadata.sorted_tables)
        if not tables:
            print("[ensure] No hay tablas en metadata. ¿Se importaron los modelos?")
            return

        print("[ensure] Revisando columnas faltantes por tabla…")

        # Usamos una sola conexión/tx y exec_driver_sql (SQLAlchemy 2.x)
        with engine.begin() as conn:
            # (Opcional) aseguramos PRAGMA; no es imprescindible para ADD COLUMN
            with suppress(Exception):
                conn.exec_driver_sql("PRAGMA foreign_keys=OFF")

            for table in tables:
                tname = table.name
                if not insp.has_table(tname):
                    print(f"  - '{tname}': no existe (debería haberse creado). Saltando…")
                    continue

                # Columnas actuales en DB
                existing_cols = {col["name"] for col in insp.get_columns(tname)}
                # Columnas del modelo
                model_cols = [c for c in table.columns]

                missing = [c for c in model_cols if c.name not in existing_cols]
                if not missing:
                    print(f"  - '{tname}': ✓ sin columnas faltantes")
                else:
                    print(f"  - '{tname}': agregando {len(missing)} columna(s) faltante(s)")
                    for col in missing:
                        try:
                            coltype = col.type.compile(dialect=engine.dialect)
                        except Exception:
                            coltype = "TEXT"  # Fallback muy básico

                        # No forzamos NOT NULL ni DEFAULT para evitar errores en SQLite
                        ddl = f'ALTER TABLE "{tname}" ADD COLUMN "{col.name}" {coltype}'
                        try:
                            conn.exec_driver_sql(ddl)
                            print(f"      · añadida: {col.name} {coltype}")
                        except Exception as e:
                            print(f"      ! error al añadir '{col.name}': {e}")

            # 3) Backfill rápido de timestamps en inspection (si existe)
            if insp.has_table("inspection"):
                try:
                    conn.exec_driver_sql(
                        """
                        UPDATE inspection
                        SET
                          created_at = COALESCE(created_at, CURRENT_TIMESTAMP),
                          updated_at = COALESCE(updated_at, CURRENT_TIMESTAMP),
                          inspection_date = COALESCE(inspection_date, created_at, CURRENT_TIMESTAMP),
                          status = COALESCE(status, 'in_progress'),
                          progress = COALESCE(progress, 0)
                        """
                    )
                    print("[ensure] Backfill en 'inspection' OK")
                except Exception as e:
                    print(f"[ensure] ! error en backfill 'inspection': {e}")

                # 4) Índices (si faltan)
                try:
                    # refrescar inspector tras cambios
                    insp = inspect(engine)
                except Exception:
                    pass
                _create_indexes_if_missing(conn, insp)

            with suppress(Exception):
                conn.exec_driver_sql("PRAGMA foreign_keys=ON")

        print("[ensure] Esquema verificado/parcheado. ✅")
        print("       Reinicia tu server con: python backend/app.py")


if __name__ == "__main__":
    ensure_schema()
