# backend/tools/debug_manuals.py
import os, sys

CURRENT_DIR = os.path.dirname(__file__)
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.app import create_app
from backend.extensions import db
from backend.models.manual import Manual

app = create_app()

with app.app_context():
    count = db.session.query(Manual).count()
    print(f"Total manuals: {count}")

    rows = db.session.query(Manual).all()
    for m in rows:
        print(m.id, m.title, m.category, m.created_at)
