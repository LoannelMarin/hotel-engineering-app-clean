# backend/tools/seed_inspection.py
from __future__ import annotations
from datetime import datetime
import os
import sys

THIS_DIR = os.path.dirname(__file__)
BACKEND_DIR = os.path.abspath(os.path.join(THIS_DIR, ".."))
PROJECT_ROOT = os.path.abspath(os.path.join(BACKEND_DIR, ".."))
for p in (PROJECT_ROOT, BACKEND_DIR):
    if p not in sys.path:
        sys.path.insert(0, p)

from backend.app import create_app  # type: ignore
from backend.config import Config    # type: ignore
from backend.extensions import db    # type: ignore
from backend.models.inspection import Inspection  # type: ignore


def main():
    app = create_app(Config)
    with app.app_context():
        ins = Inspection(
            scope_type="floors",
            scope_value="2,3",
            floors=["2", "3"],
            status="in_progress",
            progress=0,
            started_by_name="seed",
            created_at=datetime.utcnow(),
            inspection_date=datetime.utcnow(),
        )
        db.session.add(ins)
        db.session.commit()
        print(f"✅ creada inspection id={ins.id}")

if __name__ == "__main__":
    main()
