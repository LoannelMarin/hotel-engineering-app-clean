#!/usr/bin/env python3
# import_invoices_sqlite.py
# Standalone CSV/JSON importer for SQLite.
# Usage:
#   python import_invoices_sqlite.py --db path/to/app.db --input path/to/invoice_tracker_clean.csv
#   python import_invoices_sqlite.py --db path/to/app.db --input path/to/invoice_tracker_clean.json
#
# The script will create a table "invoices" if it doesn't exist and UPSERT rows
# using UNIQUE(invoice_no, vendor_name).

import argparse
import csv
import json
import sqlite3
from datetime import datetime
from pathlib import Path

EXPECTED_COLS = [
    "vendor_name",
    "invoice_no",
    "invoice_date",
    "due_date",
    "amount",
    "status",
    "notes",
    "paid",
    "currency",
]

DDL = """
CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    vendor_name TEXT NOT NULL,
    invoice_no TEXT NOT NULL,
    invoice_date TEXT,
    due_date TEXT,
    amount REAL,
    status TEXT,
    notes TEXT,
    paid INTEGER DEFAULT 0,
    currency TEXT DEFAULT 'USD',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(invoice_no, vendor_name) ON CONFLICT REPLACE
);
"""

UPSERT_SQL = """
INSERT INTO invoices
(vendor_name, invoice_no, invoice_date, due_date, amount, status, notes, paid, currency, updated_at)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'));
"""

def parse_bool(val):
    if isinstance(val, bool):
        return int(val)
    s = str(val).strip().lower()
    return 1 if s in ("1", "true", "yes", "y") else 0

def parse_date(val):
    if val in (None, "", "nan", "NaT"):
        return None
    s = str(val).strip()
    # Try multiple formats
    fmts = ["%Y-%m-%d", "%m/%d/%Y", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%fZ"]
    for f in fmts:
        try:
            return datetime.strptime(s, f).strftime("%Y-%m-%d")
        except Exception:
            continue
    # As a fallback, try fromisoformat
    try:
        return datetime.fromisoformat(s).strftime("%Y-%m-%d")
    except Exception:
        return None

def ensure_table(conn):
    conn.execute(DDL)
    conn.commit()

def load_rows(path: Path):
    ext = path.suffix.lower()
    rows = []
    if ext == ".csv":
        with path.open("r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for r in reader:
                rows.append(r)
    elif ext == ".json":
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, dict):
                data = data.get("rows", [])
            if not isinstance(data, list):
                raise ValueError("JSON must be an array of objects")
            rows = data
    else:
        raise ValueError("Unsupported input type; use .csv or .json")
    return rows

def normalize(row: dict):
    missing = [c for c in EXPECTED_COLS if c not in row]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    vendor = (row.get("vendor_name") or "").strip()
    inv = (row.get("invoice_no") or "").strip()
    inv_date = parse_date(row.get("invoice_date"))
    due = parse_date(row.get("due_date"))
    try:
        amount = float(str(row.get("amount") or "0").replace("$", "").replace(",", "").strip())
    except Exception:
        amount = 0.0
    status = (row.get("status") or "").strip()
    notes = (row.get("notes") or "").strip()
    paid = parse_bool(row.get("paid"))
    currency = (row.get("currency") or "USD").strip() or "USD"
    return (vendor, inv, inv_date, due, amount, status, notes, paid, currency)

def main():
    ap = argparse.ArgumentParser(description="Import invoices into SQLite")
    ap.add_argument("--db", required=True, help="Path to SQLite DB file (e.g., app.db)")
    ap.add_argument("--input", required=True, help="Path to CSV or JSON file to import")
    args = ap.parse_args()

    db_path = Path(args.db)
    in_path = Path(args.input)
    if not in_path.exists():
        raise SystemExit(f"Input file not found: {in_path}")

    conn = sqlite3.connect(str(db_path))
    try:
        ensure_table(conn)
        rows = load_rows(in_path)
        cur = conn.cursor()
        count = 0
        for r in rows:
            vals = normalize(r)
            cur.execute(UPSERT_SQL, vals)
            count += 1
        conn.commit()
        print(f"Imported/Upserted {count} rows into {db_path} ✅")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
