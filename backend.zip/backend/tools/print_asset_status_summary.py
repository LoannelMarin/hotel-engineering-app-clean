# backend/tools/print_asset_status_summary.py
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from backend.app import create_app, Config
from backend.extensions import db
from backend.models.asset_status import AssetStatus
from sqlalchemy import func

def main():
    app = create_app(Config)
    with app.app_context():
        bad = ["fail", "ooo"]
        total_bad = db.session.query(func.count(AssetStatus.asset_id))\
            .filter(AssetStatus.state.in_(bad)).scalar()
        total_assets = db.session.query(func.count(AssetStatus.asset_id)).scalar()

        print("=== SUMMARY ===")
        print("Assets with FAIL/OOO:", total_bad)
        print("Total tracked assets :", total_assets)

if __name__ == "__main__":
    main()
