# backend/tools/seed_assets.py
from __future__ import annotations
import os, sys
from flask import Flask

THIS_DIR = os.path.dirname(__file__)
BACKEND_DIR = os.path.abspath(os.path.join(THIS_DIR, ".."))
PROJECT_ROOT = os.path.abspath(os.path.join(BACKEND_DIR, ".."))
for p in (PROJECT_ROOT, BACKEND_DIR):
    if p not in sys.path:
        sys.path.insert(0, p)

from backend.config import Config  # type: ignore
from backend.extensions import db  # type: ignore
from backend.models.asset import Asset  # type: ignore


FLOORS = ["2", "3", "4", "5", "6", "7", "8", "Roof"]
AREAS  = ["Lobby", "Bar", "Kitchen", "Back of House", "MDF", "Gym"]


def create_seed_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)
    return app


def main():
    app = create_seed_app()
    with app.app_context():
        db.create_all()
        created = 0

        # HVAC & Detectores por piso
        for f in FLOORS:
            for i in range(1, 6):
                db.session.add(Asset(
                    name=f"FCU - Room {f}{10+i}",
                    type="FCU",
                    floor=f,
                    manufacturer="Carrier",
                    equipment="HVAC",
                )); created += 1
            for i in range(1, 4):
                db.session.add(Asset(
                    name=f"Smoke Detector - Corridor {f}-{i}",
                    type="Detector",
                    floor=f,
                    manufacturer="Honeywell",
                    equipment="Fire",
                )); created += 1

        # Extintores / Puertas por área
        for a in AREAS:
            db.session.add(Asset(
                name=f"Fire Extinguisher - {a}",
                type="Extinguisher",
                area=a,
                manufacturer="Kidde",
                equipment="Fire",
            )); created += 1
            db.session.add(Asset(
                name=f"Door - {a} emergency exit",
                type="Door",
                area=a,
                manufacturer="ASSA ABLOY",
                equipment="Door",
            )); created += 1

        db.session.commit()
        print(f"✅ Seeded {created} assets")


if __name__ == "__main__":
    main()
