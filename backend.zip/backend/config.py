# -*- coding: utf-8 -*-
import os
from pathlib import Path

# Directorio absoluto de /backend
BASE_DIR = Path(__file__).resolve().parent
# Ruta ABSOLUTA al archivo SQLite dentro de /backend
DB_FILE = BASE_DIR / "hotel_engineering.db"

def _bool(env_name: str, default: bool = False) -> bool:
    v = os.getenv(env_name)
    if v is None:
        return default
    return v.strip().lower() not in ("0", "false", "no", "off")

class Config:
    # --- claves ---
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret")
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "dev-jwt")
    JWT_TOKEN_LOCATION = ["headers"]  # Authorization: Bearer <token>

    # --- DB: permite override con DATABASE_URL; si no, fuerza SQLite local ---
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", f"sqlite:///{DB_FILE}")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Engine options (SQLite: +timeout, +check_same_thread)
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
    }
    if SQLALCHEMY_DATABASE_URI.startswith("sqlite:"):
        SQLALCHEMY_ENGINE_OPTIONS["connect_args"] = {
            "timeout": 30,
            "check_same_thread": False,  # útil si corres con threads
        }

    # En dev es cómodo crear tablas; en prod, mejor migraciones
    CREATE_ALL_ON_START = _bool("CREATE_ALL_ON_START", default=True)

    # Uploads
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", str((BASE_DIR.parent / "uploads").resolve()))
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_LENGTH", str(20 * 1024 * 1024)))  # 20MB


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False
    # En prod, por defecto NO crear tablas automáticamente
    CREATE_ALL_ON_START = _bool("CREATE_ALL_ON_START", default=False)
