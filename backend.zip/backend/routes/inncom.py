# backend/routes/inncom.py
from __future__ import annotations
from flask import Blueprint, request, jsonify, Response
from backend.extensions import db
from backend.models.inncom import InncomData
from sqlalchemy import func, desc
from datetime import datetime
import json, time

inncom_bp = Blueprint("inncom", __name__, url_prefix="/api/inncom")

# ============================================================
# 🩺 Health check
# ============================================================
@inncom_bp.get("/_health")
def inncom_health():
    return jsonify({"ok": True, "service": "inncom"}), 200


# ============================================================
# 📨 Ingesta / Actualización de estado
# ============================================================
@inncom_bp.post("/")
@inncom_bp.post("/status")
def receive_inncom_data():
    """
    Recibe datos JSON de la forma:
    {
      "room_number": "401",
      "guest_name": "John Doe",
      "status": "OCC"
    }
    Crea o actualiza el estado de la habitación.
    """
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "empty body"}), 400

    try:
        room = str(data.get("room_number")).strip()
        guest = (data.get("guest_name") or "").strip()
        status = (data.get("status") or "").strip() or "Vacant"

        if not room:
            return jsonify({"error": "missing room_number"}), 400

        row = InncomData.query.filter_by(room_number=room).first()
        if row:
            row.guest_name = guest
            row.status = status
            row.updated_at = datetime.utcnow()
            action = "updated"
        else:
            row = InncomData(
                room_number=room,
                guest_name=guest,
                status=status,
                updated_at=datetime.utcnow(),
            )
            db.session.add(row)
            action = "inserted"

        db.session.commit()
        return jsonify({"success": True, "action": action}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400


# ============================================================
# 🧾 Último estado por habitación
# ============================================================
@inncom_bp.get("/room/<string:room>/latest")
def latest_by_room(room: str):
    row = InncomData.query.filter_by(room_number=room).first()
    if not row:
        return jsonify({"error": "not found"}), 404
    return jsonify(row.to_dict()), 200


# ============================================================
# 🧱 Últimos N registros (histórico)
# ============================================================
@inncom_bp.get("/recent")
def inncom_recent():
    try:
        limit = int(request.args.get("limit", "50"))
    except Exception:
        limit = 50

    rows = (
        InncomData.query
        .order_by(desc(InncomData.updated_at))
        .limit(limit)
        .all()
    )
    return jsonify({
        "count": len(rows),
        "items": [r.to_dict() for r in rows],
    }), 200


# ============================================================
# 🔁 Stream SSE: notifica cambios en tiempo real
# ============================================================
@inncom_bp.get("/stream")
def inncom_stream():
    def event_stream():
        last_ts = None
        heartbeat_every = 25
        hb = 0
        while True:
            try:
                ts = db.session.query(func.max(InncomData.updated_at)).scalar()
                if last_ts is None:
                    yield f"data: {json.dumps({'type': 'hello'})}\n\n"
                    last_ts = ts
                if ts and ts != last_ts:
                    last_ts = ts
                    yield f"data: {json.dumps({'type': 'refresh', 'ts': ts.isoformat()})}\n\n"
                    hb = 0
                hb += 1
                if hb >= heartbeat_every:
                    yield "data: {}\n\n"
                    hb = 0
                time.sleep(1)
            except GeneratorExit:
                break
            except Exception:
                time.sleep(2)

    headers = {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
    }
    return Response(event_stream(), headers=headers)


# ============================================================
# 📊 Resumen por piso
# ============================================================
@inncom_bp.get("/overview")
def inncom_overview():
    """
    Devuelve resumen por piso, ejemplo:
    {
      "2": {"OCC": 10, "Vacant": 6},
      "3": {"OCC": 12, "Vacant": 5}
    }
    """
    data = InncomData.query.all()
    summary = {}

    for row in data:
        if not row.room_number or len(row.room_number) < 3:
            continue
        floor = row.room_number[0]  # primer dígito = piso
        status = row.status or "Unknown"
        summary.setdefault(floor, {"OCC": 0, "Vacant": 0, "Unknown": 0})
        key = status.upper()
        if key in summary[floor]:
            summary[floor][key] += 1
        else:
            summary[floor]["Unknown"] += 1

    return jsonify(summary), 200


# ============================================================
# 🌡️ Estado actual (para frontend Room Status)
# ============================================================
@inncom_bp.get("/current")
def inncom_current():
    """
    Devuelve el último estado de todas las habitaciones o las filtradas.
    Parámetros:
      - rooms=201,202,...
      - prefix=4 (solo piso 4)
    """
    rooms_param = (request.args.get("rooms") or "").strip()
    rooms = [r.strip() for r in rooms_param.split(",") if r.strip()]
    prefix = (request.args.get("prefix") or "").strip()

    subq = (
        db.session.query(
            InncomData.room_number.label("room_number"),
            func.max(InncomData.updated_at).label("max_updated"),
        )
        .group_by(InncomData.room_number)
        .subquery()
    )

    q = (
        db.session.query(InncomData)
        .join(
            subq,
            (InncomData.room_number == subq.c.room_number)
            & (InncomData.updated_at == subq.c.max_updated)
        )
    )

    if prefix:
        q = q.filter(InncomData.room_number.like(f"{prefix}%"))
    if rooms:
        q = q.filter(InncomData.room_number.in_(rooms))

    rows = q.all()
    items = {r.room_number: r.to_dict() for r in rows}
    return jsonify({"items": items, "count": len(items)}), 200
