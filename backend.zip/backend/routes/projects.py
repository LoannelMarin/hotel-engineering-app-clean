# backend/routes/projects.py
# -*- coding: utf-8 -*-
from datetime import datetime
from typing import Dict, Any, List

from flask import Blueprint, request, jsonify, g, abort
from sqlalchemy import asc

from backend.extensions import db
from backend.models.project import (
    Project,
    ProjectRoomStatus,
    ProjectRoomAudit,
)

bp = Blueprint("projects", __name__, url_prefix="/projects")


# ---------- Utilidades ----------

DEFAULT_LEGEND = {
    "Complete": "#10b981",     # emerald-500
    "In Progress": "#f59e0b",  # amber-500
    "Blocked": "#6366f1",      # indigo-500
    "Missing": "#ef4444",      # red-500
    "N/A": "#9ca3af",          # gray-400
}


def _current_user_email() -> str:
    """
    Toma el email del usuario autenticado en g.user.email; como fallback
    acepta el header 'X-User-Email' (útil en dev).
    """
    if getattr(g, "user", None) and getattr(g.user, "email", None):
        return g.user.email
    return request.headers.get("X-User-Email") or ""


def _serialize_room(rs: ProjectRoomStatus) -> Dict[str, Any]:
    return rs.to_dict()


def _room_ranges() -> List[range]:
    """
    Genera los rangos del Aloft:
      201–216 y 301–317 para los pisos 3–8.
    """
    ranges = [range(201, 217)]
    for floor in range(3, 9):  # 3..8
        start = floor * 100 + 1
        end = floor * 100 + 17
        ranges.append(range(start, end + 1))
    return ranges


def _all_room_numbers() -> List[str]:
    nums = []
    for r in _room_ranges():
        nums.extend([str(n) for n in r])
    return nums


def _ensure_rooms(project_id: int) -> None:
    """
    Crea registros ProjectRoomStatus para todas las habitaciones que no existan aún.
    """
    existing = {
        r.room_number
        for r in ProjectRoomStatus.query.with_entities(ProjectRoomStatus.room_number)
        .filter_by(project_id=project_id)
        .all()
    }
    missing = [rn for rn in _all_room_numbers() if rn not in existing]
    if not missing:
        return

    db.session.bulk_save_objects(
        [
            ProjectRoomStatus(
                project_id=project_id,
                room_number=rn,
                status="N/A",
            )
            for rn in missing
        ]
    )
    db.session.commit()


# ---------- Endpoints de Proyectos ----------

@bp.get("/")
def list_projects():
    items = Project.query.order_by(asc(Project.name)).all()
    return jsonify({"items": [p.to_dict() for p in items]})


@bp.post("/")
def create_project():
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    if not name:
        abort(400, description="Missing project name")

    p = Project(
        name=name,
        color_legend=data.get("color_legend") or DEFAULT_LEGEND,
    )
    db.session.add(p)
    db.session.commit()

    # Asegurar habitaciones iniciales
    _ensure_rooms(p.id)

    return jsonify(p.to_dict()), 201


@bp.get("/<int:pid>")
def get_project(pid: int):
    p = Project.query.get_or_404(pid)
    return jsonify(p.to_dict())


@bp.put("/<int:pid>")
def update_project(pid: int):
    p = Project.query.get_or_404(pid)
    data = request.get_json() or {}

    if "name" in data:
        name = (data.get("name") or "").strip()
        if not name:
            abort(400, description="Invalid name")
        p.name = name

    if "color_legend" in data and isinstance(data["color_legend"], dict):
        p.color_legend = data["color_legend"]

    db.session.commit()
    return jsonify(p.to_dict())


@bp.delete("/<int:pid>")
def delete_project(pid: int):
    p = Project.query.get_or_404(pid)
    db.session.delete(p)
    db.session.commit()
    return jsonify({"ok": True})


# ---------- Habitaciones & Leyenda ----------

@bp.get("/<int:pid>/rooms")
def list_rooms(pid: int):
    Project.query.get_or_404(pid)
    _ensure_rooms(pid)
    rows = (
        ProjectRoomStatus.query
        .filter_by(project_id=pid)
        .order_by(asc(ProjectRoomStatus.room_number))
        .all()
    )
    return jsonify({"items": [_serialize_room(r) for r in rows]})


@bp.put("/<int:pid>/legend")
def update_legend(pid: int):
    p = Project.query.get_or_404(pid)
    data = request.get_json() or {}
    legend = data.get("color_legend")
    if not isinstance(legend, dict):
        abort(400, description="color_legend must be an object")
    p.color_legend = legend
    db.session.commit()
    return jsonify(p.to_dict())


# ---------- Estado de habitación + Auditoría ----------

@bp.put("/<int:pid>/room/<string:room>")
def set_room_status(pid: int, room: str):
    Project.query.get_or_404(pid)
    _ensure_rooms(pid)

    rs = ProjectRoomStatus.query.filter_by(project_id=pid, room_number=str(room)).first()
    if not rs:
        rs = ProjectRoomStatus(project_id=pid, room_number=str(room), status="N/A")
        db.session.add(rs)
        db.session.flush()

    data = request.get_json() or {}
    prev_status = rs.status
    new_status = data.get("status", prev_status)
    if new_status is None:
        new_status = prev_status

    rs.status = new_status
    rs.notes = data.get("notes", rs.notes or "")
    rs.updated_by = _current_user_email()
    # updated_at se maneja con onupdate, pero forzamos cambio
    rs.updated_at = datetime.utcnow()

    audit = ProjectRoomAudit(
        project_id=pid,
        room_number=str(room),
        prev_status=prev_status,
        new_status=new_status,
        notes=data.get("notes", ""),
        updated_by=rs.updated_by,
    )
    db.session.add(audit)
    db.session.commit()

    return jsonify(_serialize_room(rs))


@bp.get("/<int:pid>/room/<string:room>/audits")
def list_room_audits(pid: int, room: str):
    Project.query.get_or_404(pid)
    q = (
        ProjectRoomAudit.query
        .filter_by(project_id=pid, room_number=str(room))
        .order_by(ProjectRoomAudit.id.desc())
        .limit(200)
    )
    return jsonify({"items": [a.to_dict() for a in q.all()]})
