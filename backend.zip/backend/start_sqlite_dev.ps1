# backend/start_sqlite_dev.ps1
param(
  [int]$Port = 5000
)

$ErrorActionPreference = "Stop"

Set-Location $PSScriptRoot
if (-not (Test-Path ".\.venv\Scripts\Activate.ps1")) {
  throw "No se encontró .venv. Crea el entorno: python -m venv .venv"
}

# Activar venv
. .\.venv\Scripts\Activate.ps1

# Variables
$env:FLASK_APP = "app"
$env:FLASK_ENV = "development"
$env:DATABASE_URL = "sqlite:///local.db"

# Migraciones (idempotente)
if (Test-Path .\migrations) {
  Write-Host "Migraciones ya existen. Ejecutando upgrade..."
} else {
  flask db init
  flask db migrate -m "initial schema"
}
flask db upgrade

# Arrancar
flask run --host 0.0.0.0 --port $Port
